﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoTesteInterface
{
    public interface IfcContratoFigura
    {
        public interface IfcContratoFigura
        {
            public int retornarNumeroObjetosFigura(); //retorna o número de instâncias do tipo figura
        }
    }
}
